/*1. Please loop through this string ( var isWeather = "It's sunny today!" ) using a for loop and console.log out every character as a result*/
var qeue = document.getElementById("qeue");

var letters = [];

var isWeather = "It's sunny today!" 

for(i = 0;i < isWeather.length;i++){
    
    var letter = isWeather.charAt(i); 
    console.log(letter);
}

/*2. After this create a variable to store the characters in, and add a star after each character.*/
for(i = 0;i < isWeather.length;i++){
    
    var letter = isWeather.charAt(i) + "*"; 
    
    var text = document.createTextNode(letter);
    var node = document.createElement("p");
    
    node.appendChild(text);
    
    qeue.appendChild(node);
}

/*3. Now find an HTML element on your page, assign the id attribute to it, find it by it's id, and add your string to the innerHTML of the element. " (I*t*'*s* *s*u*n*n*y* *t*o*d*a*y*!*")*/
var letters = [];
var three = document.getElementById("three");

for(i = 0;i < isWeather.length;i++){
    
    var letter = isWeather.charAt(i) + "*";
    letters.push(letter);
}

var stringStars = letters.join(' ');

three.innerHTML = stringStars;

/*4. Now you have this printed on your page, in your for loop use the index number to determine the even numbers (Use math in the for loop condition, use google to find: For loop for even numbers), and only add the * with after every second characters. ( I*t'*s *su*nn*y *to*da*y!*)*/
var letters = [];
var four = document.getElementById("four");

for (i = 0; i <=isWeather.length;i++){
    if(i % 2 == 0){
        var letter = isWeather.charAt(i) + "*";
        letters.push(letter);
    } else {
        var letter = isWeather.charAt(i);
        letters.push(letter);
    }
}
var evenStars = letters.join(" ");

four.innerHTML = evenStars;

/*5.Now add the number which holds the sum of all characters in your string (spaces count also as a character) right after the last character with some more text concatenated.
( "It's sunny today! Length of this string is "17")*/
var isWeatherLength = isWeather.length;
var five = document.getElementById("five");
var concatfunc = function (){
    var concat = isWeather + " Length of this string is " + isWeatherLength + "!!!";
    return concat;
}

five.innerHTML = concatfunc();

/*6.Inside your for loop set a conditional statement: If the index is even add a *, else if the index is odd add a $, else if the index is the last index add a @. */
var letters = [];
var six = document.getElementById("six");
var diffcharacters;

for (i = 0; i <isWeather.length;i++){
    
    if(i == isWeather.length) {
            var letter = isWeather.charAt(i) + "@";
            letters.push(letter);
        
    } else if (i % 2 == 0){
        var letter = isWeather.charAt(i) + "*";
        letters.push(letter);
    } else {
        var letter = isWeather.charAt(i) +"$" ;
        letters.push(letter);
    }
}


var diffcharacters = letters.join(' ');

six.innerHTML = diffcharacters;